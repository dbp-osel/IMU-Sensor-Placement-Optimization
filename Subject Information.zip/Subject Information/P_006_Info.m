%% Sensor indexes
% Serial 76E = 0;
% Serial 77B = 1;
% Serial 783 = 2;
% Serial 8AE = 3;
% Serial 8C6 = 4;
% Serial 8C8 = 5;
% Serial 8D7 = 6;
% Serial 8DF = 7;
% Serial 8E1 = 8;
% Serial 8F0 = 9;
% Serial 451 = 10;

clear all
num.LowThighAnt =   5;
num.ShinBone =      4;
num.LowShankLat =   8;
num.Sacrum =        1;
num.LowThighPos =   7;
num.MidThighLat =   0;
num.Heel =          10;
num.LowThighLat =   2;
num.L4L5 =          6;
num.MidShankLat =   9;
num.DFoot =         10; %Actually 3, Dfoot sensor file empty, replacing with heel to make code work

NumberSensors = 11;
%%
TaskList = strcat('1: Calibration',10,...
    '2: TUG');
%% Medial-Lateral Guesses
%+X down
guess.LowThighAnt=[0 -1 0];
guess.ShinBone=[0 -1/sqrt(2) -1/sqrt(2)];
guess.LowShankLat=[0 0 1];
guess.Sacrum=[0 1 0];
guess.LowThighPos=[0 1 0];
guess.MidThighLat=[0 0 1];
guess.Heel=[0 1 0];
guess.LowThighLat=[0 0 1];
guess.L4L5=[0 1 0];
guess.MidShankLat=[0 0 1];
guess.DFoot=[0 1 0];
%% Text File Format
AccColumns = 18:20;
RVelColumns = 27:29;
QuatColumnOne = 44;
RowStart = 7;
%% Frame Rate (Hz)
FR = 60;
%% Save
save('P_006_Info')