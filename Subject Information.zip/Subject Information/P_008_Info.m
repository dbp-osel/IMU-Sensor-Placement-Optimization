%% Sensor indexes
% Serial 76E = 0;
% Serial 77B = 1;
% Serial 783 = 2;
% Serial 8AE = 3;
% Serial 8C6 = 4;
% Serial 8C8 = 5;
% Serial 8D7 = 6;
% Serial 8DF = 7;
% Serial 8E1 = 8;
% Serial 8F0 = 9;
% Serial 451 = 10;

clear all
num.LowThighAnt =   2;
num.ShinBone =      7;
num.LowShankLat =   4;
num.Sacrum =        5;
num.LowThighPos =   1;
num.MidThighLat =   3;
num.Heel =          8;  %Large offset induced by turning. Likely due to large sensor bias.
num.LowThighLat =   9;
num.L4L5 =          0;
num.MidShankLat =   6;
num.DFoot =         10;

NumberSensors = 11;
%%
TaskList = strcat('1: Calibration',10,...
    '2: TUG');

%% Medial-Lateral Guesses
%+X down
guess.LowThighAnt=[0 -1 0];
guess.ShinBone=[0 -1/sqrt(2) -1/sqrt(2)];
guess.LowShankLat=[0 0 1];
guess.Sacrum=[0 1 0];
guess.LowThighPos=[0 1 0];
guess.MidThighLat=[0 0 1];
guess.Heel=[0 1 0];
guess.LowThighLat=[0 0 1];
guess.L4L5=[0 1 0];
guess.MidShankLat=[0 0 1];
guess.DFoot=-1*[-0.163800242150748,0.927156577666590,-0.336972048040980];
%% Text File Format
AccColumns = 18:20;
RVelColumns = 27:29;
QuatColumnOne = 44;
RowStart = 7;
%% Frame Rate (Hz)
FR = 60;
%% Save
save('P_008_Info')