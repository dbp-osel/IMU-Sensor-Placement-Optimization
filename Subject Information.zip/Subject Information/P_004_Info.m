%% Sensor indexes
% Serial 76E = 0;
% Serial 77B = 1;
% Serial 783 = 2;
% Serial 8AE = 3;
% Serial 8C6 = 4;
% Serial 8C8 = 5;
% Serial 8D7 = 6;
% Serial 8DF = 7;
% Serial 8E1 = 8;
% Serial 8F0 = 9;
% Serial 451 = 10;

clear all
num.LowThighAnt =   5;
num.ShinBone =      4;
num.LowShankLat =   0;
num.Sacrum =        10;
num.LowThighPos =   3;
num.MidThighLat =   7;
num.Heel =          9;
num.LowThighLat =   1;
num.L4L5 =          8;
num.MidShankLat =   2;
num.DFoot =         6;

NumberSensors = 11;
%% Task List
TaskList = strcat('1: Calibration',10,...
    '2: TUG');
%% Medial-Lateral Guesses
%+X down
guess.LowThighAnt=[0 -1 0];
guess.ShinBone=[0 -1/sqrt(2) -1/sqrt(2)];
guess.LowShankLat=[0 0 1];
guess.Sacrum=[0 1 0];
guess.LowThighPos=[0 1 0];
guess.MidThighLat=[0 0 1];
guess.Heel=[0 1 0];
guess.LowThighLat=[0 0 1];
guess.L4L5=[0 1 0];
guess.MidShankLat=[0 0 1];
guess.DFoot= -1*[-0.186680610982662,0.904570146158092,-0.383279532668609];
%% Text File Format
AccColumns = 18:20;
RVelColumns = 27:29;
QuatColumnOne = 44;
RowStart = 7;
%% Frame Rate (Hz)
FR = 60;
%% Save
save('P_004_Info')